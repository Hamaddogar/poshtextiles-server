import { Grid, TextField, Typography } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'
import { subHeadInputStyle, Wrapper } from '../reUseAbles/ReuseAbles';





const Topcontent = () => {


    const [orderDetail] = React.useState({});

    return (
        <div>
            <Wrapper justifyContent={'space-around'} >
                    <Wrapper margin='5px 10px' >
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Bill To: </Typography>
                        <TextField defaultValue={orderDetail.billTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Project Name: </Typography>
                        <TextField defaultValue={orderDetail.projectName} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Terms: </Typography>
                        <TextField defaultValue={orderDetail.terms} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Ship To: </Typography>
                        <TextField defaultValue={orderDetail.shipTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Priority: </Typography>
                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Specifier: </Typography>
                        <TextField defaultValue={orderDetail.specifier} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Order Date: </Typography>
                        <TextField defaultValue={orderDetail.orderDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Sales Person: </Typography>
                        <TextField defaultValue={orderDetail.salesPerson} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Customer PO: </Typography>
                        <TextField defaultValue={orderDetail.customerPO} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Campaign: </Typography>
                        <TextField defaultValue={orderDetail.campaign} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>




                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Req Ship Date: </Typography>
                        <TextField defaultValue={orderDetail.reqShipDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>

                    <Grid container style={{ marginTop: "20px" }}>
                    <Grid item xs={6}>
                        <Box style={{ border: "2px solid black", maxWidth: "85%", padding: "3px 0px" }}>
                            <p style={{ fontSize: "10px", textAlign: "center" }}>Sales History</p>
                            <label style={{ marginLeft: "20px" }} for="poqty">6M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />
                            <label style={{ marginLeft: "20px" }} for="poqty">7-12M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />
                            <label style={{ marginLeft: "20px" }} for="poqty">13-24M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />

                        </Box>
                    </Grid>
                    <Grid item xs={5}>
                        <label for="poqty">Ready Goods: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                        <label for="poqty">Available: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                    </Grid>
                </Grid>

                </Wrapper>
            {/* <Box style={{ maxWidth: "80%" }}>
                <Grid container justifyContent={"space-around"}>
                    <Grid item xs={4}>
                        <label for="itmsrc">Item Search: </label>
                        <input style={{ marginLeft: "15px" }} type="text" id="itmsrc" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="onhand">On Hand: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="onhand" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="sqty">SO Qty: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="sqty" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="poqty">PO Qty: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                    </Grid>
                </Grid>

                <Grid container style={{ marginTop: "20px" }} justifyContent={"space-around"}>
                    <Grid item xs={4}>
                        <label for="itmsrc">Description: </label>
                        <input style={{ marginLeft: "15px" }} type="text" id="itmsrc" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="onhand">At Mill: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="onhand" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="sqty">Transit Qty: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="sqty" name="name" />
                    </Grid>
                    <Grid item xs={2}>
                        <label for="poqty">Available: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                    </Grid>
                </Grid>

                <Grid container style={{ marginTop: "20px" }}>
                    <Grid item xs={6}>
                        <Box style={{ border: "2px solid black", maxWidth: "85%", padding: "3px 0px" }}>
                            <p style={{ fontSize: "10px", textAlign: "center" }}>Sales History</p>
                            <label style={{ marginLeft: "20px" }} for="poqty">6M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />
                            <label style={{ marginLeft: "20px" }} for="poqty">7-12M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />
                            <label style={{ marginLeft: "20px" }} for="poqty">13-24M: </label>
                            <input style={{ maxWidth: "50px" }} type="text" id="poqty" name="name" />

                        </Box>
                    </Grid>
                    <Grid item xs={5}>
                        <label for="poqty">Ready Goods: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                        <label for="poqty">Available: </label>
                        <input style={{ maxWidth: "50px", marginLeft: "20px" }} type="text" id="poqty" name="name" />
                    </Grid>
                </Grid>
            </Box> */}
        </div>
    )
}

export default Topcontent