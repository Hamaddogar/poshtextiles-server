import { Checkbox, CircularProgress, ClickAwayListener, Grow, MenuList, Popper, Stack, TextField, Typography } from '@mui/material';
import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Grid } from '@mui/material';
import Paper from '@mui/material/Paper';
import { Button } from '@mui/material';
import MenuItem from '@mui/material/MenuItem';
import { Box } from '@mui/system';
import Pagination from 'react-responsive-pagination';
import 'bootstrap/dist/css/bootstrap.css';
import { DeleteOutline, EditOutlined, KeyboardArrowDown, } from '@mui/icons-material';
import BackArrow from '../../../assets/icons/back-arrow.png'
import { subHeadInputStyle, Wrapper } from '../reUseAbles/ReuseAbles';
import BasicModal from './Modal';
import { SELECT_PICKING_PRODUCT } from '../../../../RTK/Reducers/Reducers';



const SalesOrders = () => {

    const { saleOrderDetails, status } = useSelector(store => store.mainReducer);
    const [copy, setCopy] = React.useState([]);
    const [rows, setRows] = React.useState([]);
    const [currentPage, setCurrentPage] = React.useState(1);
    const [orderDetail] = React.useState(saleOrderDetails.orderDetail);
    const [showSelectedProduct, setShowSelectedProduct] = React.useState(null);
    const [dropShipChecked, setDropShipChecked] = React.useState(false);

    const navigate = useNavigate();
    const dispatch = useDispatch();


    const handlePageChange = page => {
        setCurrentPage(page);
        setRows(copy.slice(((page - 1) * 9), ((((page - 1) * 9)) + 9)))
    }

    React.useLayoutEffect(() => { setCopy(saleOrderDetails.saleOrders) }, [saleOrderDetails]);
    React.useEffect(() => { setRows(copy.slice(0, 9)) }, [copy]);

    // const handleClick = (event) => setAnchorEl(event.currentTarget);
    // const handleClose = () => setAnchorEl(null);
    const handleShowSelectedProduct = product => setShowSelectedProduct(product);

    const handleSelectedPickingProduct = product => {
        dispatch(SELECT_PICKING_PRODUCT(product));
        navigate('/picking')
    };



    // for actions 
    const [open, setOpen] = React.useState(false);
    const anchorRef = React.useRef(null);

    const handleToggle = () => setOpen((prevOpen) => !prevOpen);

    const handleClose = (event) => {
        if (anchorRef.current && anchorRef.current.contains(event.target)) { return; }
        setOpen(false);
    };

    function handleListKeyDown(event) {
        if (event.key === 'Tab') {
            event.preventDefault();
            setOpen(false);
        } else if (event.key === 'Escape') setOpen(false);
    }

    // return focus to the button when we transitioned from !open -> open
    const prevOpen = React.useRef(open);
    React.useEffect(() => {
        if (prevOpen.current === true && open === false) anchorRef.current.focus();
        prevOpen.current = open;
    }, [open]);




    // Modal Options
    const [Modalopen, setModalopen] = React.useState(false);
    const handleOpen = () => setModalopen(true);


    return (
        <div>
            <BasicModal Modalopen={Modalopen} setModalopen={setModalopen} />

            {/* <Button onClick={handleOpen} sx={{background:"dodgerBlue"}} variant="contained">Comments</Button> */}
            {/* {showSelectedProduct && <SelectedProduct product={showSelectedProduct} /> } */}
            {!rows.length > 0 && status !== 'pending' && <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}><CircularProgress /></Box>}
            {rows.length > 0 && <Box>
                <Wrapper justifyContent={'space-around'} >
                    <Wrapper margin='5px 10px' >
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Bill To: </Typography>
                        <TextField defaultValue={orderDetail.billTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Project Name: </Typography>
                        <TextField defaultValue={orderDetail.projectName} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Terms: </Typography>
                        <TextField defaultValue={orderDetail.terms} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Ship To: </Typography>
                        <TextField defaultValue={orderDetail.shipTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Priority: </Typography>
                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Specifier: </Typography>
                        <TextField defaultValue={orderDetail.specifier} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Order Date: </Typography>
                        <TextField defaultValue={orderDetail.orderDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Sales Person: </Typography>
                        <TextField defaultValue={orderDetail.salesPerson} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Customer PO: </Typography>
                        <TextField defaultValue={orderDetail.customerPO} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Campaign: </Typography>
                        <TextField defaultValue={orderDetail.campaign} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>




                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Req Ship Date: </Typography>
                        <TextField defaultValue={orderDetail.reqShipDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                </Wrapper>
                <Box sx={{ padding: showSelectedProduct ? '15px' : '0px' }} mb={1}>
                    <Box sx={{ transition: '.5s', border: '1px solid black', boxShadow: `1px 1px 2px 1px rgba(0, 0, 0, 0.25)`, display: 'flex', alignItems: 'flex-start', padding: showSelectedProduct ? '15px' : '0px' }}>
                        {showSelectedProduct && <>
                            <Box>
                                <Box component='img' alt='img' style={{ width: '100%', minWidth: '146px', maxWidth: '146px', cursor: 'pointer' }} src={showSelectedProduct.image} />
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>

                                <Wrapper justifyContent={'flex-start'} >
                                    <Wrapper margin='3px 10px' >
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Type: </Typography>
                                        <TextField defaultValue={orderDetail.billTo} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Name: </Typography>
                                        <TextField defaultValue={orderDetail.projectName} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Description: </Typography>
                                        <TextField defaultValue={orderDetail.terms} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Drop Ship: </Typography>
                                        <Checkbox
                                            checked={dropShipChecked}
                                            onChange={e => setDropShipChecked(e.target.checked)}
                                            inputProps={{ 'aria-label': 'controlled' }}
                                        />
                                    </Wrapper>


                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Number: </Typography>
                                        <TextField defaultValue={orderDetail.shipTo} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>


                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Min Quantity: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>
                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity Selected: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper justifyContent={{ xs: 'center', md: 'space-between' }} margin='3px 10px' width='100%' spacing={2} >
                                        <TextField onClick={handleOpen} defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '80%', }} fullWidth />
                                        <Box margin='5px 0px'>
                                            <Button color='error' variant='contained' size='small' onClick={e => setShowSelectedProduct(null)}>cancel</Button> &nbsp;
                                            <Button color='primary' variant='contained' size='small'>ok</Button>
                                        </Box>
                                    </Wrapper>




                                </Wrapper>

                            </Box>
                        </>
                        }
                    </Box>
                </Box>


                <Box sx={{ padding: '15px', backgroundColor: 'white' }}>
                    <Box sx={{ padding: '15px', border: '1px solid black', borderStyle: 'inset' }}>
                        <Grid container alignItems={'center'} rowGap={3} sx={{ margin: '10px' }}>
                            {rows && rows.map((item, index) => <Grid xs={12} sm={6} md={4} item justifyContent='space-between' key={index} sx={{ minHeight: '100px', }} >
                                <Box sx={{ cursor: 'pointer' }} px={{ xs: '1', md: 2, lg: 3 }} onClick={() => handleSelectedPickingProduct(item)}>
                                    <Grid container justifyContent='space-between'>
                                        <Grid xs={6} item> <Box component='img' alt='img' style={{ width: '100%', maxWidth: '146px', cursor: 'pointer' }} src={item.image} /> </Grid>
                                        <Grid item container direction={'column'} justifyContent={'space-between'} xs={6} px={1} sx={{ position: 'relative' }}>

                                            <Stack sx={{ height: '100%', display: 'flex', justifyContent: 'space-between' }} >
                                                <Typography textAlign='center' mt={1} variant='h1' fontSize={{ xs: '18px', sm: '25px', md: '30px' }} fontWeight={500} >JEROME SAHARA</Typography>
                                                <Stack direction='row' alignItems={'center'} justifyContent='space-between'>
                                                    <Typography fontSize='12px'>MOQ : <span style={{ fontSize: '20px' }}>{item.moq}</span></Typography>
                                                    <Typography fontSize='12px' textAlign={'right'}>QTY : <span style={{ fontSize: '20px' }}>{item.qty}</span></Typography>
                                                </Stack>
                                            </Stack>
                                            <Stack sx={{ position: 'absolute', right: 0 }}>
                                                <DeleteOutline sx={{ cursor: 'pointer', color: '#404040', tranisition: '.5s', '&:hover': { color: '#E23C2F' } }}
                                                    onClick={e => {
                                                        e.stopPropagation();
                                                        rows.splice(index, 1)
                                                        setRows([...rows]);
                                                    }}
                                                />
                                                <EditOutlined sx={{ cursor: 'pointer', color: '#404040', tranisition: '.5s', '&:hover': { color: '#495BD6' } }}
                                                    onClick={e => {
                                                        e.stopPropagation();
                                                        handleShowSelectedProduct(item)
                                                    }}
                                                />
                                            </Stack>
                                        </Grid>
                                    </Grid>
                                </Box>

                            </Grid>)
                            }
                        </Grid>
                    </Box >
                </Box>





            </Box >}
            {
                rows.length === 0 && <Box mt={3} textAlign='center' >
                    <Typography>No Record</Typography>
                </Box>
            }
            {
                rows.length > 0 &&
                <Grid spacing={3} container direction='row' my={3} textAlign='right' mt={2} justifyContent={{ xs: 'center', md: 'space-between' }} alignItems={'center'}>
                    <Grid item>
                        <Box>
                            <Button startIcon={<img src={BackArrow} alt='back' width='18px' />} variant='contained' color='error' size='small' onClick={() => navigate(-1)}> Go back</Button>
                            &nbsp; &nbsp; &nbsp;
                            <Button
                                variant='contained'
                                sx={{ backgroundColor: '#495BD6' }}
                                size='small'
                                ref={anchorRef}
                                id="composition-button"
                                aria-controls={open ? 'composition-menu' : undefined}
                                aria-expanded={open ? 'true' : undefined}
                                aria-haspopup="true"
                                onClick={handleToggle}
                                endIcon={<KeyboardArrowDown />}
                            > Actions </Button>
                        </Box>
                    </Grid>
                    <Grid item>
                        <Button variant='contained' size='small'> + add new item</Button>
                    </Grid>
                    <Grid item>
                        <Pagination
                            total={Math.ceil(copy.length / 9)}
                            current={currentPage}
                            onPageChange={page => handlePageChange(page)}
                        />
                    </Grid>
                </Grid>
            }

            <Popper
                open={open}
                anchorEl={anchorRef.current}
                role={undefined}
                placement="bottom-start"
                transition
                disablePortal
            >
                {({ TransitionProps, placement }) => (
                    <Grow {...TransitionProps} style={{ transformOrigin: placement === 'bottom-start' ? 'left top' : 'left bottom', }}>
                        <Paper>
                            <ClickAwayListener onClickAway={handleClose}>
                                <MenuList
                                    autoFocusItem={open}
                                    id="composition-menu"
                                    aria-labelledby="composition-button"
                                    onKeyDown={handleListKeyDown}
                                    sx={{ backgroundColor: '#495BD6', color: 'white' }}
                                >
                                    {/* <MenuItem onClick={handleClose}>Profile</MenuItem> */}
                                    <MenuItem sx={{ borderBottom: '1px solid white' }} >Profile</MenuItem>
                                    <MenuItem sx={{ borderBottom: '1px solid white' }} >My account</MenuItem>
                                    <MenuItem >Logout</MenuItem>
                                </MenuList>
                            </ClickAwayListener>
                        </Paper>
                    </Grow>
                )}
            </Popper>
        </div >
    )
}

export default SalesOrders
