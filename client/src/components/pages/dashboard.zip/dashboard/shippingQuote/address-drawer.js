import * as React from 'react';
import Box from '@mui/material/Box';
import SwipeableDrawer from '@mui/material/SwipeableDrawer';
import Button from '@mui/material/Button';
import { Grid, Typography } from '@mui/material';

export default function AddressValidateDrawer() {
    const [state, setState] = React.useState({
        left: false
    });

    const toggleDrawer = (anchor, open) => (event) => {
        if (
            event &&
            event.type === 'keydown' &&
            (event.key === 'Tab' || event.key === 'Shift')
        ) {
            return;
        }

        setState({ ...state, [anchor]: open });
    };

    const list = (anchor) => (
        <Box
            sx={{ width: anchor === 'top' || anchor === 'bottom' ? 'auto' : 500, height: "100vh", padding: "10px 0px 0px 30px", background: "#E9EDF1" }}
            role="presentation"
        >
            <Typography >* Represents fields Required</Typography>

            <Grid container>
                <Grid item xs={12} md={6}>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>Company Name<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>Address Line 1<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>City<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>Postal Code<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Button disabled sx={{ background: "#A4A4A4", padding: "3px 9px", marginTop: "15px" }}>Validate</Button>
                </Grid>
                <Grid item xs={12} md={6} >
                    <Box sx={{ marginTop: "20px" }}>
                        <label>Address Line 2<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>State<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                    <Box sx={{ marginTop: "20px" }}>
                        <label>Country<font style={{ color: "red" }}>*</font></label><br />
                        <input type="text" style={{ border: "0px", width: "90%", marginTop: "10px" }} />
                    </Box>
                </Grid>
            </Grid>

        </Box>
    );

    return (
        <div>
            {['left'].map((anchor) => (
                <React.Fragment key={anchor}>
                    <Button style={{ background: "#4B5AD8", marginTop: "15px", padding: "0px 6px", color: "white" }} onClick={toggleDrawer(anchor, true)}>Validate Address</Button>
                    <SwipeableDrawer
                        anchor={anchor}
                        open={state[anchor]}
                        onClose={toggleDrawer(anchor, false)}
                        onOpen={toggleDrawer(anchor, true)}
                    >
                        {list(anchor)}
                    </SwipeableDrawer>
                </React.Fragment>
            ))}
        </div>
    );
}