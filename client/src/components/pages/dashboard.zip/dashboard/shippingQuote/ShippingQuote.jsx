import { Button, Grid } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'
import { useNavigate } from 'react-router-dom'
import AddressValidateDrawer from './address-drawer'
import RateQuoteDrawer from './ratequote-drawer'
import './quote.css'

const ShippingQuote = () => {
    const navigate = useNavigate();


    return (
        <div>
            {/* <Box component={'img'} src={shape} alt=" " sx={{maxWidth:'1000px', width:'100%'}} /> */}
            <Grid container>
                <Grid item xs={12} md={6} >
                    <Box>
                        <label for="roll">Print On:</label>
                        <select id="roll" style={{ marginLeft: "8px", width: "60%", borderRadius: "5px", border: "0px", padding: "4px 3px" }}>
                            <option label="roll1">Roll- 4" x 6" Shipping label</option>
                            <option label="roll2">Roll- 4" x 6" Shipping label</option>
                            <option label="roll3">Roll- 4" x 6" Shipping label</option>
                            <option label="roll4">Roll- 4" x 6" Shipping label</option>
                        </select>
                    </Box>
                    <Box className="mt">
                        <label for="roll">Ship From:</label>
                        <select id="roll" style={{ marginLeft: "8px", width: "60%", borderRadius: "5px", border: "0px", padding: "4px 3px" }}>
                            <option label="Post Textile">1</option>
                            <option label="roll2">1</option>
                            <option label="roll3">1</option>
                            <option label="roll4">1</option>
                        </select>
                    </Box>
                    <Box className="formfield mt">
                        <label for="w3review">Ship To:</label>
                        <textarea style={{ marginLeft: "8px", width: "100%", maxWidth: "380px" }} id="w3review" name="w3review" rows="4" cols="50">
                        </textarea>
                    </Box>
                    <Box className="mt">
                        <label for="roll">Carrier:</label>
                        <select id="roll" style={{ marginLeft: "8px", width: "60%", borderRadius: "5px", border: "0px", padding: "4px 3px" }}>
                            <option label="UPS">Roll- 4" x 6" Shipping label</option>
                            <option label="roll2">Roll- 4" x 6" Shipping label</option>
                            <option label="roll3">Roll- 4" x 6" Shipping label</option>
                            <option label="roll4">Roll- 4" x 6" Shipping label</option>
                        </select>
                    </Box>
                    <Box className="mt">
                        <label for="roll">Service:</label>
                        <select id="roll" style={{ marginLeft: "8px", width: "60%", borderRadius: "5px", border: "0px", padding: "4px 3px" }}>
                            <option label="Ground">Roll- 4" x 6" Shipping label</option>
                            <option label="roll2">Roll- 4" x 6" Shipping label</option>
                            <option label="roll3">Roll- 4" x 6" Shipping label</option>
                            <option label="roll4">Roll- 4" x 6" Shipping label</option>
                        </select>
                    </Box>
                    <Box className="mt">
                        <label for="roll">Carrier:</label>
                        <input type="text" style={{ border: "0px", borderRadius: "5px", marginLeft: "10px" }} />
                    </Box>
                    <Box className="mt">
                        <label for="roll">Email Tracking:</label>
                        <input type="text" placeholder='Email add , for multipe emails' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "60%" }} />
                    </Box>
                    <Box className="mt">
                        <label for="roll">Ship Date:</label>
                        <input type="date" placeholder='Email add , for multipe emails' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "60%", padding: "5px" }} />
                    </Box>



                </Grid>
                <Grid item xs={12} md={6}>
                    <Box className="mt">
                        <label for="roll">No. of Boxes:</label>
                        <input type="number" placeholder='1' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "30%" }} />
                    </Box>
                    <Box className="mt">
                        <label for="roll">Weight:</label>
                        <input type="number" placeholder='0.00' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "10%" }} />
                        <label for="roll">lbs:</label>
                        <input type="number" placeholder='0.00' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "10%" }} />
                        <label for="roll">oz:</label>
                        <input type="number" placeholder='0.00' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "10%" }} />
                        <label for="roll">Auto:</label>
                        <input type="checkbox" style={{ border: "0px", width: "10%" }} />
                    </Box>
                    <Box className="mt">
                        <label for="roll">Insure for $:</label>
                        <input type="number" placeholder='0.00' style={{ border: "0px", borderRadius: "5px", marginLeft: "10px", width: "60%" }} />
                    </Box>
                    <Box className="mt">
                        <label for="roll">Extra Service:</label>
                        <select id="roll" style={{ marginLeft: "15px", textAlign: "center", appearance: "none", width: "15%", borderRadius: "5px", border: "0px", padding: "4px 3px", background: "#E0E0E0" }}>
                            <option label="Select">Roll- 4" x 6" Shipping label</option>
                            <option label="roll2">Roll- 4" x 6" Shipping label</option>
                            <option label="roll3">Roll- 4" x 6" Shipping label</option>
                            <option label="roll4">Roll- 4" x 6" Shipping label</option>
                        </select>
                    </Box>

                </Grid>

                <Grid item container>
                    <Grid item xs={6}>
                        <Box>
                            <Box>
                                <AddressValidateDrawer />
                                {/* <Button style={{background:"#4B5AD8",marginTop:"15px",padding:"0px 6px"}}>Validate Address</Button> */}
                            </Box>
                            <Box sx={{ marginTop: "10px" }}>
                                <Button variant='contained' style={{ background: "red", color: "white" }} size='small' onClick={() => navigate(-1)}> Go back</Button>
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={6}>
                        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
                            {/* <Button style={{background:"#4B5AD8",marginTop:"15px",padding:"0px 6px"}}>Rate Quote</Button> */}
                            <RateQuoteDrawer />
                            <Button style={{ marginLeft: "6px", background: "#4B5AD8", marginTop: "15px", padding: "0px 6px" }}>Ship</Button>

                        </Box>
                    </Grid>
                </Grid>
            </Grid>
        </div>
    )
}

export default ShippingQuote
