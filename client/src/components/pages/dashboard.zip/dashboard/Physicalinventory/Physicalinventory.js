import { Box, Button } from '@mui/material'
import { Stack } from '@mui/system'
import React from 'react'
import './inventory.css'
import Pinventorytable from './Pinventorytable'

const Physicalinventory = () => {
    return (
        <div>
            <Box sx={{ border: "1px solid black", padding: "14px 12px 8px 30px" }}>
                <Box sx={{ width: "60%", margin: "auto" }}>
                    <Stack direction={"row"} justifyContent={"space-around"}>
                        <Button sx={{ background: "#FFFFFF", border: "1px solid black", color: "black", padding: "20px 40px" }}>A22</Button>
                        <Button sx={{ background: "#FFFFFF", border: "1px solid black", color: "black", padding: "20px 40px" }}>LO121</Button>
                        <Button sx={{ background: "#FFFFFF", border: "1px solid black", color: "black", padding: "20px 40px" }}>10</Button>
                    </Stack>
                </Box>
                <Box sx={{ textAlign: "right" }}>
                    <Button variant="contained" sx={{ background: "#495BD6", color: "white" }}>OK</Button>
                </Box>
            </Box>
            <Box>
                <Pinventorytable />
            </Box>
        </div>
    )
}

export default Physicalinventory