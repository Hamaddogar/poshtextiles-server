import { Checkbox, CircularProgress, Stack, TextField, Typography } from '@mui/material';
import React from 'react'
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Grid } from '@mui/material';
import { Button } from '@mui/material';
import { Box } from '@mui/system';
import 'bootstrap/dist/css/bootstrap.css';
import BackArrow from '../../../assets/icons/back-arrow.png'
import { subHeadInputStyle, Wrapper } from '../reUseAbles/ReuseAbles';
import { orderDetail } from '../../../../RTK/Reducers/fakeData';
import { Settings } from '@mui/icons-material';
import PickingTable from './PickingTable';
import fabric from '../../../assets/icons/fabric.png';
import shelf from '../../../assets/icons/shelf.png';








const Picking = () => {

    const { pickingSelectedProduct, status } = useSelector(store => store.mainReducer);
    const [showSelectedProduct, setShowSelectedProduct] = React.useState(null);
    const [dropShipChecked, setDropShipChecked] = React.useState(false);
    const navigate = useNavigate();
    React.useLayoutEffect(() => { setShowSelectedProduct(pickingSelectedProduct) }, [pickingSelectedProduct]);

    return (
        <div>
            {!showSelectedProduct && status !== 'pending' && <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}><CircularProgress /></Box>}
            {showSelectedProduct && <Box>
                <Wrapper justifyContent={'space-around'} >
                    <Wrapper margin='5px 10px' >
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Bill To: </Typography>
                        <TextField defaultValue={orderDetail.billTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Project Name: </Typography>
                        <TextField defaultValue={orderDetail.projectName} size='small' sx={subHeadInputStyle} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Terms: </Typography>
                        <TextField defaultValue={orderDetail.terms} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Ship To: </Typography>
                        <TextField defaultValue={orderDetail.shipTo} size='small' sx={subHeadInputStyle} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Priority: </Typography>
                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>

                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Specifier: </Typography>
                        <TextField defaultValue={orderDetail.specifier} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>


                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Order Date: </Typography>
                        <TextField defaultValue={orderDetail.orderDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Sales Person: </Typography>
                        <TextField defaultValue={orderDetail.salesPerson} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Customer PO: </Typography>
                        <TextField defaultValue={orderDetail.customerPO} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Campaign: </Typography>
                        <TextField defaultValue={orderDetail.campaign} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>




                    <Wrapper margin='5px 10px'>
                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Req Ship Date: </Typography>
                        <TextField defaultValue={orderDetail.reqShipDate} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                    </Wrapper>



                </Wrapper>
                <Box sx={{ padding: showSelectedProduct ? '15px' : '0px' }} mb={1}>
                    <Box sx={{ transition: '.5s', border: '1px solid black', boxShadow: `1px 1px 2px 1px rgba(0, 0, 0, 0.25)`, display: 'flex', alignItems: 'flex-start', padding: showSelectedProduct ? '15px' : '0px' }}>
                        {showSelectedProduct && <>
                            <Box>
                                <Box component='img' alt='img' style={{ width: '100%', minWidth: '146px', maxWidth: '146px', cursor: 'pointer' }} src={showSelectedProduct.image} />
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>

                                <Wrapper justifyContent={'flex-start'} >
                                    <Wrapper margin='3px 10px' >
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Type: </Typography>
                                        <TextField defaultValue={orderDetail.billTo} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Name: </Typography>
                                        <TextField defaultValue={orderDetail.projectName} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Description: </Typography>
                                        <TextField defaultValue={orderDetail.terms} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Drop Ship: </Typography>
                                        <Checkbox
                                            checked={dropShipChecked}
                                            onChange={e => setDropShipChecked(e.target.checked)}
                                            inputProps={{ 'aria-label': 'controlled' }}
                                        />
                                    </Wrapper>


                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Number: </Typography>
                                        <TextField defaultValue={orderDetail.shipTo} size='small' sx={subHeadInputStyle} />
                                    </Wrapper>


                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Min Quantity: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>
                                    <Wrapper margin='3px 10px'>
                                        <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity Selected: </Typography>
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                                    </Wrapper>

                                    <Wrapper justifyContent={{ xs: 'center', md: 'space-between' }} margin='3px 10px' width='100%' spacing={2} >
                                        <TextField defaultValue={orderDetail.priority} size='small' sx={{ ...subHeadInputStyle, minWidth: '80%', }} fullWidth />
                                        <Box margin='5px 0px'>
                                            <Button color='error' variant='contained' size='small' onClick={e => setShowSelectedProduct(pickingSelectedProduct)}>cancel</Button> &nbsp;
                                            <Button color='primary' variant='contained' size='small'>ok</Button>
                                        </Box>
                                    </Wrapper>




                                </Wrapper>

                            </Box>
                        </>
                        }
                    </Box>
                </Box>
                <Box sx={{ padding: '15px', backgroundColor: 'white' }}>
                    <Box sx={{ padding: '15px', border: '1px solid black', borderStyle: 'inset' }}>
                        <Box >
                            <Stack direction='row' justifyContent={"center"} spacing={4}>
                                <Box sx={{ display: "flex", alignItems: "center" }}>
                                    <Box component='img' alt='img' src={shelf} />
                                    <Button variant='outlined' sx={{ color: '#6D6D6D', border: '1px solid #1D1D1E', borderRadius: 0 }} size='large' startIcon={<Settings />} >Scan Bin</Button>
                                </Box>
                                <Box sx={{ display: "flex", alignItems: "center" }}>
                                    <Box component='img' alt='img' src={fabric} />
                                    <Button variant='outlined' sx={{ color: '#6D6D6D', border: '1px solid #1D1D1E', borderRadius: 0 }} size='large' startIcon={<Settings />} >Scan LOT</Button>
                                </Box>
                            </Stack>

                            <Box maxWidth={'sm'} margin='20px auto auto auto' >
                                <PickingTable />
                            </Box>

                        </Box>
                    </Box >
                </Box>

            </Box >}
            <Grid spacing={3} container direction='row' my={3} textAlign='right' mt={2} justifyContent={{ xs: 'center', md: 'space-between' }} alignItems={'center'}>
                <Grid item>
                    <Button startIcon={<img src={BackArrow} alt='back' width='18px' />} variant='contained' color='error' size='small' onClick={() => navigate(-1)}> Go back</Button>
                </Grid>
            </Grid>

        </div >
    )
}

export default Picking
