import { Box, Button, Checkbox, Pagination, TextField, Typography } from '@mui/material'
import { Stack } from '@mui/system';
import React from 'react'
import { useSelector } from 'react-redux';
import Pinventorytable from '../Physicalinventory/Pinventorytable';
import { BackButton, subHeadInputStyle, Wrapper } from '../reUseAbles/ReuseAbles'


const InventoryAdjustment = () => {

    const { pickingSelectedProduct } = useSelector(store => store.mainReducer);
    const [showSelectedProduct, setShowSelectedProduct] = React.useState(null);
    const [dropShipChecked, setDropShipChecked] = React.useState(false);

    React.useLayoutEffect(() => { setShowSelectedProduct(pickingSelectedProduct) }, [pickingSelectedProduct]);

    return (
        <div>
            <Box sx={{ padding: showSelectedProduct ? '15px' : '0px' }} mb={1}>
                <Box sx={{ transition: '.5s', border: '1px solid black', boxShadow: `1px 1px 2px 1px rgba(0, 0, 0, 0.25)`, display: 'flex', alignItems: 'flex-start', padding: showSelectedProduct ? '15px' : '0px' }}>
                    <Box sx={{ padding: '15px' }} >
                        {
                            showSelectedProduct ?
                                <Box component='img' alt='img' style={{ width: '100%', minWidth: '146px', maxWidth: '146px', cursor: 'pointer' }} src={showSelectedProduct.image} />
                                :
                                <Box style={{ width: '100%', minWidth: '146px', maxWidth: '146px', cursor: 'pointer', backgroundColor: 'white', minHeight: '140px' }}></Box>
                        }
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>

                        <Wrapper justifyContent={'flex-start'} >
                            <Wrapper margin='3px 10px' >
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Type: </Typography>
                                <TextField size='small' sx={subHeadInputStyle} />
                            </Wrapper>

                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Name: </Typography>
                                <TextField size='small' sx={subHeadInputStyle} />
                            </Wrapper>

                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Description: </Typography>
                                <TextField size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                            </Wrapper>

                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Drop Ship: </Typography>
                                <Checkbox
                                    checked={dropShipChecked}
                                    onChange={e => setDropShipChecked(e.target.checked)}
                                    inputProps={{ 'aria-label': 'controlled' }}
                                />
                            </Wrapper>


                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Item Number: </Typography>
                                <TextField size='small' sx={subHeadInputStyle} />
                            </Wrapper>


                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity: </Typography>
                                <TextField size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                            </Wrapper>

                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Min Quantity: </Typography>
                                <TextField size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                            </Wrapper>
                            <Wrapper margin='3px 10px'>
                                <Typography mr={1} sx={{ color: '#6D6D6D' }}>Quantity Selected: </Typography>
                                <TextField size='small' sx={{ ...subHeadInputStyle, minWidth: '5rem', maxWidth: '5rem' }} />
                            </Wrapper>

                            <Wrapper justifyContent={{ xs: 'center', md: 'space-between' }} margin='3px 10px' width='100%' spacing={2} >
                                <TextField size='small' sx={{ ...subHeadInputStyle, minWidth: '80%', }} fullWidth />
                                <Box margin='5px 0px'>
                                    <Button color='primary' disabled variant='contained' size='small'>ok</Button>
                                </Box>
                            </Wrapper>
                        </Wrapper>

                    </Box>
                </Box>

                {/* table */}
                <Box my={2}>
                    <Pinventorytable />
                </Box>
                {/* actions */}
                <Stack direction='row' alignItems={'center'} justifyContent='space-between' >
                    <BackButton />
                    <Stack direction='row' my={3} textAlign='right' mt={2} justifyContent='space-between' alignItems={'center'}>
                        <Button variant='contained' size='small' disabled> Accept</Button>
                        <Pagination />
                    </Stack>
                </Stack>

            </Box>
        </div>
    )
}

export default InventoryAdjustment;