import { Stack, Typography } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';
import { useSelector } from 'react-redux';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthCheck } from '../../../utils/auth';
import Header from '../../header/Header';
import saleorder from '../../assets/icons/saleorder.png';
import inspection from '../../assets/icons/inspection.png';
import picking from '../../assets/icons/picking.png';
import packing from '../../assets/icons/packing.png';
import cutting from '../../assets/icons/cutting.png';
import shipping from '../../assets/icons/shipping.png';


const Dashboard = () => {
    AuthCheck();
    const { isAuthorised } = useSelector(store => store.mainReducer);
    const [title, setTitle] = React.useState(null)

    React.useLayoutEffect(() => {
        setTitle(null)
        const path = window.location.pathname;
        if (path === "/sale-order") setTitle({ text: 'Sale Orders', icon: saleorder });
        else if (path === "/inspection") setTitle({ text: 'INSPECTION', icon: inspection });
        else if (path === "/picking") setTitle({ text: 'PICKING', icon: picking });
        else if (path === '/inspect-cut') setTitle({ text: 'INS-CUT', icon: cutting });
        else if (path === "/cutting") setTitle({ text: 'CUTTING', icon: cutting });
        else if (path === "/packing") setTitle({ text: 'PACKING', icon: packing });
        else if (path === "/shipping") setTitle({ text: 'SHIPPING', icon: shipping });
        else if (path === "/history") setTitle({ text: 'History', icon: shipping });
        //eslint-disable-next-line
    }, [window.location.pathname]);




    return isAuthorised ?
        <Box sx={{ backgroundColor: '#E9EDF1', minHeight: '100vh' }}>
            <Header />
            <Box id='holder'>
                <Box id="left-bar" sx={{ paddingLeft: '5px', fontWeight: 600 }}>

                    <Box id='title-section'>
                        <Stack columnGap={2} direction='row' alignItems='center'>
                            {title && <Box component={'img'} src={title.icon} alt={' '} sx={{ width: '100%', maxWidth: '50px' }} />}
                            <Typography fontSize={{ xs: '22px', sm: '50px', md: '65px' }} > {title?.text} </Typography>
                        </Stack>
                    </Box>
                </Box>
                <Box id='displayer'> <Outlet /> </Box>
            </Box>
        </Box>
        : <Navigate to="/login" replace={true} />
}

export default Dashboard
