import React from 'react'

const Logistics = () => {
    return (
        <div>
            Logistics
        </div>
    )
}

export default Logistics
