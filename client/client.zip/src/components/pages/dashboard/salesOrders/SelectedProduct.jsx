import React from 'react'

const SelectedProduct = ({product}) => {
  return (
    <div>SelectedProduct</div>
  )
}

export default SelectedProduct