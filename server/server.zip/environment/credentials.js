module.exports = {
    SECRETS: {
        GRANT_TYPE_FEDEXP: 'client_credentials',
        CLIENT_ID_FEDEXP: 'l7f3e40fe52f194710907c05dd71fe4df3',
        CLIENT_SECRET_FEDEXP: '3de32885a68543c9b0ddebf86f5489e9',

        GRANT_TYPE_MICROSOFT: 'client_credentials',
        CLIENT_ID_MICROSOFT: "743c2eb9-f173-4c31-a92d-8d514eb7ece8",
        CLIENT_SECRET_MICROSOFT: ".Tj8Q~T--p1GIsM_WfNt5Y6eSR6v4BrdZ.Lw1c~B",
        SCOPE_MICROSOFT: "https://graph.microsoft.com/.default",

    }

};